﻿using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace CapaDatos
{
    public class ProductoDAL
    {
        public int Insertar(Producto producto)
        {
            using (var cn = Conexion.Instancia.ObtenerConexion()) 
            {
                cn.Open();
                var cmd = new SqlCommand(
                    "INSERT INTO Producto (Descripcion, Precio) " +
                    "OUTPUT INSERTED.ProductoId VALUES (@Descripcion, @Precio)",
                    cn);

                cmd.Parameters.AddWithValue("@Descripcion", producto.Descripcion);
                cmd.Parameters.AddWithValue("@Precio", producto.Precio);

                return (int)cmd.ExecuteScalar();
            }
        }

        public void Actualizar(Producto producto)
        {
            using (var cn = Conexion.Instancia.ObtenerConexion()) 
            {
                cn.Open();
                var cmd = new SqlCommand(
                    "UPDATE Producto SET Descripcion = @Descripcion, Precio = @Precio " +
                    "WHERE ProductoId = @ProductoId", cn);

                cmd.Parameters.AddWithValue("@ProductoId", producto.ProductoId);
                cmd.Parameters.AddWithValue("@Descripcion", producto.Descripcion);
                cmd.Parameters.AddWithValue("@Precio", producto.Precio);

                cmd.ExecuteNonQuery();
            }
        }

        public Producto Obtener(int id)
        {
            using (var cn = Conexion.Instancia.ObtenerConexion()) 
            {
                cn.Open();
                var cmd = new SqlCommand(
                    "SELECT ProductoId, Descripcion, Precio FROM Producto " +
                    "WHERE ProductoId = @ProductoId", cn);

                cmd.Parameters.AddWithValue("@ProductoId", id);

                using (var dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        return new Producto
                        {
                            ProductoId = dr.GetInt32(0),
                            Descripcion = dr.GetString(1),
                            Precio = dr.GetDecimal(2)
                        };
                    }
                }
                return null;
            }
        }

        public DataTable Listar()
        {
            using (var cn = Conexion.Instancia.ObtenerConexion()) 
            {
                var dt = new DataTable();
                var da = new SqlDataAdapter(
                    "SELECT ProductoId, Descripcion, Precio FROM Producto", cn);
                da.Fill(dt);
                return dt;
            }
        }
    }
}
