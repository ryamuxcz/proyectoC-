﻿using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace CapaDatos
{
    public class VentaDAL
    {
        
        public int Insertar(Venta venta, SqlConnection cn, SqlTransaction tx)
        {
            var cmd = new SqlCommand(
                "INSERT INTO Venta (ClienteId, Fecha, Total) " +
                "OUTPUT INSERTED.VentaId VALUES (@ClienteId, @Fecha, @Total)",
                cn, tx);

            cmd.Parameters.AddWithValue("@ClienteId", venta.ClienteId);
            cmd.Parameters.AddWithValue("@Fecha", venta.Fecha);
            cmd.Parameters.AddWithValue("@Total", venta.Total);

            return (int)cmd.ExecuteScalar();
        }

        
        public DataTable ListarVentas()
        {
            var dt = new DataTable();
            string query = @"
                SELECT v.VentaId, c.Nombre AS Cliente, v.Fecha, v.Total
                FROM Venta v
                INNER JOIN Cliente c ON v.ClienteId = c.ClienteId
                ORDER BY v.Fecha DESC";

            using (var cn = Conexion.Instancia.ObtenerConexion())
            {
                using (var da = new SqlDataAdapter(query, cn))
                {
                    da.Fill(dt);
                }
            }
            return dt;
        }

        
        public DataTable ListarDetalleVenta(int ventaId)
        {
            var dt = new DataTable();
            string query = @"
                SELECT p.Descripcion, dv.Cantidad, dv.Subtotal
                FROM DetalleVenta dv
                INNER JOIN Producto p ON dv.ProductoId = p.ProductoId
                WHERE dv.VentaId = @VentaId";

            using (var cn = Conexion.Instancia.ObtenerConexion())
            {
                using (var cmd = new SqlCommand(query, cn))
                {
                    cmd.Parameters.AddWithValue("@VentaId", ventaId);
                    using (var da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }
    }
}
